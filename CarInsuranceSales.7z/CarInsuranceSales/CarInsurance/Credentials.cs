﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarInsurance
{
    public class Credentials
    {
        [JsonProperty(PropertyName = "admin")]
        public string Username { get; set; }
        [JsonProperty(PropertyName = "vta6tR_tj5nu")]
        public string Password { get; set; }
    }
}

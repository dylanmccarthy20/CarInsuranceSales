﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarInsurance
{
    public partial class UpdateQuote : Form
    {
        MainMenu parent;
        CouchRepository couch = new CouchRepository(_id,_rev);
      
        public UpdateQuote()
        {
            InitializeComponent();
        }
        public UpdateQuote(MainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }

        private void UpdateQuote_Load(object sender, EventArgs e)
        {

        }

        private void UpdQuoteTlStpMnu_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void UpdDeleteQuoteMnu_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void UpdViewQuotesMnu_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void BTMnuTLStrip_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void Update(object sender, EventArgs e)
        {
            couch.PostDocumentAsync(txtFName.Text,txtLName.Text)
        }
    }
}

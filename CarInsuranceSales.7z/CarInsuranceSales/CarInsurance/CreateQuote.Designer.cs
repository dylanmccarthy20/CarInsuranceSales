﻿
namespace CarInsurance
{
    partial class CreateQuote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.BTMnuTLStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPhn = new System.Windows.Forms.TextBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.lblAccidents = new System.Windows.Forms.Label();
            this.cboaccident = new System.Windows.Forms.ComboBox();
            this.lblPoints = new System.Windows.Forms.Label();
            this.cboPoints = new System.Windows.Forms.ComboBox();
            this.lblNCB = new System.Windows.Forms.Label();
            this.cboNCB = new System.Windows.Forms.ComboBox();
            this.lblType = new System.Windows.Forms.Label();
            this.cboLicence = new System.Windows.Forms.ComboBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cboTitle = new System.Windows.Forms.ComboBox();
            this.txtCarReg = new System.Windows.Forms.TextBox();
            this.lblCarReg = new System.Windows.Forms.Label();
            this.lblLname = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.lblDOB = new System.Windows.Forms.Label();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.lbldtp = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMnuTLStrip});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // BTMnuTLStrip
            // 
            this.BTMnuTLStrip.Name = "BTMnuTLStrip";
            this.BTMnuTLStrip.Size = new System.Drawing.Size(180, 29);
            this.BTMnuTLStrip.Text = "Back to Main Menu";
            this.BTMnuTLStrip.Click += new System.EventHandler(this.BTMnuTLStrip_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblPhone);
            this.groupBox1.Controls.Add(this.txtPhn);
            this.groupBox1.Controls.Add(this.btnCreate);
            this.groupBox1.Controls.Add(this.lblAccidents);
            this.groupBox1.Controls.Add(this.cboaccident);
            this.groupBox1.Controls.Add(this.lblPoints);
            this.groupBox1.Controls.Add(this.cboPoints);
            this.groupBox1.Controls.Add(this.lblNCB);
            this.groupBox1.Controls.Add(this.cboNCB);
            this.groupBox1.Controls.Add(this.lblType);
            this.groupBox1.Controls.Add(this.cboLicence);
            this.groupBox1.Controls.Add(this.lblTitle);
            this.groupBox1.Controls.Add(this.cboTitle);
            this.groupBox1.Controls.Add(this.txtCarReg);
            this.groupBox1.Controls.Add(this.lblCarReg);
            this.groupBox1.Controls.Add(this.lblLname);
            this.groupBox1.Controls.Add(this.lblFname);
            this.groupBox1.Controls.Add(this.txtLName);
            this.groupBox1.Controls.Add(this.txtFName);
            this.groupBox1.Controls.Add(this.lblDOB);
            this.groupBox1.Controls.Add(this.dtpDOB);
            this.groupBox1.Controls.Add(this.lbldtp);
            this.groupBox1.Controls.Add(this.dtpDate);
            this.groupBox1.Location = new System.Drawing.Point(12, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(765, 360);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter Details:";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(6, 251);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(119, 20);
            this.lblPhone.TabIndex = 22;
            this.lblPhone.Text = "Phone Number:";
            // 
            // txtPhn
            // 
            this.txtPhn.Location = new System.Drawing.Point(154, 248);
            this.txtPhn.MaxLength = 10;
            this.txtPhn.Name = "txtPhn";
            this.txtPhn.Size = new System.Drawing.Size(174, 26);
            this.txtPhn.TabIndex = 21;
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(301, 300);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(189, 44);
            this.btnCreate.TabIndex = 20;
            this.btnCreate.Text = "Submit";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.createQuote);
            // 
            // lblAccidents
            // 
            this.lblAccidents.AutoSize = true;
            this.lblAccidents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAccidents.Location = new System.Drawing.Point(366, 208);
            this.lblAccidents.Name = "lblAccidents";
            this.lblAccidents.Size = new System.Drawing.Size(210, 20);
            this.lblAccidents.TabIndex = 19;
            this.lblAccidents.Text = "Accidents in the last 5 years:";
            // 
            // cboaccident
            // 
            this.cboaccident.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboaccident.FormattingEnabled = true;
            this.cboaccident.Items.AddRange(new object[] {
            "0",
            "1",
            "2+"});
            this.cboaccident.Location = new System.Drawing.Point(597, 205);
            this.cboaccident.Name = "cboaccident";
            this.cboaccident.Size = new System.Drawing.Size(68, 28);
            this.cboaccident.TabIndex = 18;
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPoints.Location = new System.Drawing.Point(443, 149);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(113, 20);
            this.lblPoints.TabIndex = 17;
            this.lblPoints.Text = "Penalty Points:";
            // 
            // cboPoints
            // 
            this.cboPoints.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPoints.FormattingEnabled = true;
            this.cboPoints.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboPoints.Location = new System.Drawing.Point(597, 153);
            this.cboPoints.Name = "cboPoints";
            this.cboPoints.Size = new System.Drawing.Size(68, 28);
            this.cboPoints.TabIndex = 16;
            // 
            // lblNCB
            // 
            this.lblNCB.AutoSize = true;
            this.lblNCB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNCB.Location = new System.Drawing.Point(422, 114);
            this.lblNCB.Name = "lblNCB";
            this.lblNCB.Size = new System.Drawing.Size(134, 20);
            this.lblNCB.TabIndex = 15;
            this.lblNCB.Text = "No Claims Bonus:";
            // 
            // cboNCB
            // 
            this.cboNCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNCB.FormattingEnabled = true;
            this.cboNCB.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10+"});
            this.cboNCB.Location = new System.Drawing.Point(597, 109);
            this.cboNCB.Name = "cboNCB";
            this.cboNCB.Size = new System.Drawing.Size(68, 28);
            this.cboNCB.TabIndex = 14;
            this.cboNCB.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(6, 208);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(127, 20);
            this.lblType.TabIndex = 13;
            this.lblType.Text = "Type Of Licence:";
            // 
            // cboLicence
            // 
            this.cboLicence.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLicence.FormattingEnabled = true;
            this.cboLicence.Items.AddRange(new object[] {
            "Full Irish",
            "Provisional"});
            this.cboLicence.Location = new System.Drawing.Point(154, 204);
            this.cboLicence.Name = "cboLicence";
            this.cboLicence.Size = new System.Drawing.Size(174, 28);
            this.cboLicence.TabIndex = 12;
            this.cboLicence.SelectedIndexChanged += new System.EventHandler(this.cboLicence_SelectedIndexChanged);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(81, 33);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(42, 20);
            this.lblTitle.TabIndex = 11;
            this.lblTitle.Text = "Title:";
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // cboTitle
            // 
            this.cboTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTitle.FormattingEnabled = true;
            this.cboTitle.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboTitle.Location = new System.Drawing.Point(141, 29);
            this.cboTitle.Name = "cboTitle";
            this.cboTitle.Size = new System.Drawing.Size(121, 28);
            this.cboTitle.TabIndex = 10;
            // 
            // txtCarReg
            // 
            this.txtCarReg.Location = new System.Drawing.Point(165, 155);
            this.txtCarReg.Name = "txtCarReg";
            this.txtCarReg.Size = new System.Drawing.Size(163, 26);
            this.txtCarReg.TabIndex = 9;
            this.txtCarReg.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblCarReg
            // 
            this.lblCarReg.AutoSize = true;
            this.lblCarReg.Location = new System.Drawing.Point(16, 158);
            this.lblCarReg.Name = "lblCarReg";
            this.lblCarReg.Size = new System.Drawing.Size(128, 20);
            this.lblCarReg.TabIndex = 8;
            this.lblCarReg.Text = "Car Registration:";
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Location = new System.Drawing.Point(33, 114);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(90, 20);
            this.lblLname.TabIndex = 7;
            this.lblLname.Text = "Last Name:";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Location = new System.Drawing.Point(33, 71);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(90, 20);
            this.lblFname.TabIndex = 6;
            this.lblFname.Text = "First Name:";
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(141, 111);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(231, 26);
            this.txtLName.TabIndex = 5;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(141, 69);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(231, 26);
            this.txtFName.TabIndex = 4;
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblDOB.Location = new System.Drawing.Point(443, 71);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(103, 20);
            this.lblDOB.TabIndex = 3;
            this.lblDOB.Text = "Date of Birth:";
            this.lblDOB.Click += new System.EventHandler(this.label1_Click);
            // 
            // dtpDOB
            // 
            this.dtpDOB.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDOB.Location = new System.Drawing.Point(567, 69);
            this.dtpDOB.MaxDate = new System.DateTime(2004, 12, 31, 0, 0, 0, 0);
            this.dtpDOB.MinDate = new System.DateTime(1915, 11, 1, 0, 0, 0, 0);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(134, 26);
            this.dtpDOB.TabIndex = 2;
            this.dtpDOB.Value = new System.DateTime(2004, 12, 31, 0, 0, 0, 0);
            // 
            // lbldtp
            // 
            this.lbldtp.AutoSize = true;
            this.lbldtp.Location = new System.Drawing.Point(459, 33);
            this.lbldtp.Name = "lbldtp";
            this.lbldtp.Size = new System.Drawing.Size(87, 20);
            this.lbldtp.TabIndex = 1;
            this.lbldtp.Text = "Start Date:";
            this.lbldtp.Click += new System.EventHandler(this.lbldtp_Click);
            // 
            // dtpDate
            // 
            this.dtpDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDate.Location = new System.Drawing.Point(567, 29);
            this.dtpDate.MaxDate = new System.DateTime(2023, 12, 31, 0, 0, 0, 0);
            this.dtpDate.MinDate = new System.DateTime(2022, 11, 1, 0, 0, 0, 0);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(134, 26);
            this.dtpDate.TabIndex = 0;
            // 
            // CreateQuote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "CreateQuote";
            this.Text = "CreateQuote";
            this.Load += new System.EventHandler(this.CreateQuote_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BTMnuTLStrip;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbldtp;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.TextBox txtCarReg;
        private System.Windows.Forms.Label lblCarReg;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.ComboBox cboNCB;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.ComboBox cboLicence;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cboTitle;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Label lblAccidents;
        private System.Windows.Forms.ComboBox cboaccident;
        private System.Windows.Forms.Label lblPoints;
        private System.Windows.Forms.ComboBox cboPoints;
        private System.Windows.Forms.Label lblNCB;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtPhn;
    }
}
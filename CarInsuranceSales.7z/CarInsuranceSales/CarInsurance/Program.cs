﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CouchDbClient
{
    class Program
    {
       using(var client = new MyCouchClient("http://admin:vta6tR_tj5nu@localhost:5984", "car_insurance"))
        {       
        FileWebRequest.Configue(q=>q
            .Stale(bool value)
            .IncludeDocs(bool value)
            .Descending(bool value)
            .Key(string value)
            .Keys(params string[] value)
            .StartKey(string value)
            .StartKeyDocId(string value)
            .EndKey(string value)
            .EndKeyDocId(string value)
            .InclusiveEnd(bool value)
            .Skip(int value)
            .Limit(int value)
            .Reduce(bool value)
            .UpdateSeq(bool value)
            .Group(bool value)
            .GroupLevel(int value))
    
            var query = new QueryViewRequest("na", "personal_details").Configure(query => query
            .Limit(5)
            .Reduce(false));

        ViewQueryResponse<string> result = await client.Views.QueryAsync(query);

        var query = new QueryViewRequest("_all_docs");
        var response = await client.Views.QueryAsync<dynamic>(query);

    }
}
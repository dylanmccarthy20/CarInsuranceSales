﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarInsurance
{
    public partial class CreateQuote : Form
    {
        CouchRepository couch=new CouchRepository();
        MainMenu parent;
        public CreateQuote()
        {
            InitializeComponent();
        }
        public CreateQuote(MainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }

        private void CreateQuote_Load(object sender, EventArgs e)
        {

        }

        private void BTMnuTLStrip_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void lbldtp_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        [HttpPost]
        public async Task<IActionResult> PostAsync([FromBody] CreateQuote createQuote)
        {
            CreateQuote.startDate = DateTime.Now;
            var result = await _couchRepository.PostDocumentAsync(createQuote);
            if (result.IsSuccess)
            {
                var sResult = JsonConvert.DeserializeObject<SavedResult>(result.SuccessContentObject);
                return new CreatedResult("Success", sResult);
            }

            return new UnprocessableEntityObjectResult(result.FailedReason);
        }
        private void createQuote(object sender, EventArgs e)
        {                                    
            Quotes newquote = new Quotes(cboTitle.Text, txtFName.Text, txtLName.Text, (String.Format("{0:dd-MMM-yy}", dtpDOB.Value)), (String.Format("{0:dd-MMM-yy}", dtpDate.Value)),
                txtCarReg.Text, cboLicence.Text, Convert.ToInt32(cboNCB.Text), Convert.ToInt32(cboPoints.Text),txtPhn.Text);

            couch.PutDocumentAsync(newquote);

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {
            var database = new Database("car_insurance");
            String id = null;
            using (var mutableDoc = new MutableDocument())
            {
                mutableDoc.setFloat("version", 2.0f).SetString("type", "SDK");
                database.save(mutableDoc);
            }
            // Update a document
            using (var doc = database.GetDocument(id))
            using (var mutableDoc = doc.ToMutable())
            {
                mutableDoc.SetString("language", "C#");
                database.Save(mutableDoc);

                using (var docAgain = database.GetDocument(id))
                {
                    Console.WriteLine($"Document ID :: {docAgain.Id}");
                    Console.WriteLine($"Learning {docAgain.GetString("language")}");
                }
            }

            // Create a query to fetch documents of type SDK
            // i.e. SELECT * FROM database WHERE type = "SDK"
            using (var query = QueryBuilder.Select(SelectResult.All())
                .From(DataSource.Database(database))
                .Where(Expression.Property("type").EqualTo(Expression.String("SDK"))))
            {
                // Run the query
                var result = query.Execute();
                Console.WriteLine($"Number of rows :: {result.Count()}");
            }

            // Create replicator to push and pull changes to and from the cloud
            var targetEndpoint = new URLEndpoint(new Uri("ws://localhost:4984/getting-started-db"));
            var replConfig = new ReplicatorConfiguration(database, targetEndpoint);

            // Add authentication
            replConfig.Authenticator = new BasicAuthenticator("john", "pass");

            // Create replicator (make sure to add an instance or static variable
            // named _Replicator)
            _Replicator = new Replicator(replConfig);
            _Replicator.AddChangeListener((sender, args) =>
            {
                if (args.Status.Error != null)
                {
                    Console.WriteLine($"Error :: {args.Status.Error}");
                }
            });

            _Replicator.Start();

            // Later, stop and dispose the replicator *before* closing/disposing the database
        }

        private void cboLicence_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

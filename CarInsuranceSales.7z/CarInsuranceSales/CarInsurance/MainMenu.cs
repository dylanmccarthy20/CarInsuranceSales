﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarInsurance
{
    public partial class MainMenu : Form
    {
      
        public MainMenu()
        {
            InitializeComponent();
        }

        private void MainMnuCreateQuote_Click(object sender, EventArgs e)
        {
            this.Hide();
            CreateQuote newQuote = new CreateQuote(this);
            newQuote.Show();
        }

        private void MainMnuUpdQuote_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateQuote updQuote = new UpdateQuote(this);
            updQuote.Show();
        }

        private void MainMnudeleteQuote_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteQuote DelQuote = new DeleteQuote(this);
            DelQuote.Show();
        }

        private void MainMnuviewQuotes_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewQuote showQuote = new ViewQuote(this);
            showQuote.Show();
        }
    }
}

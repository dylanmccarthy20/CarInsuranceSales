﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarInsurance
{
    class Quotes
    {

        private String FName;
        private String LName;
        private String title;
        private String dob;
        private String startDate;
        private String carRegNo;
        private String typeLicence;
        private int accidents;
        private int claims;
        private int points;
        private int phnNo;
        public Quotes()
        {
            FName = "null";
            LName = "null";
            title = "null";
            dob = "null";
            startDate = "null";
            carRegNo = "null";
            typeLicence = "null";
            accident = 0;
            claims = 0;
            points = 0;
            phnNo = 0;
        }
        
        public Quotes (String titles, String firstName, String lastName,String dobirth,String starts,
            String carReg, String type,int accidents, int claim, int PenaltyPts, int phn) 
        {
            this.FName = firstName;
            this.LName = lastName;
            this.title = titles;
            this.dob = dobirth;
            this.startDate = starts;
            this.carRegNo = carReg;
            this.typeLicence = type;
            this.accident = accidents;
            this.claims = claim;
            this.points = PenaltyPts;
            this.phnNo = phn;
        }
        
        public void setTitle(String titles)
        {
            this.title = titles;
        }
        public void setFName(String Fname)
        {
            this.FName = Fname;
        }
        public void setLName(String Lname)
        {
            this.LName = Lname;
        }
        public void setDOB(String dobirth)
        {
            this.dob = dobirth;
        }
        public void setStart(String StartDate)
        {
            this.startDate = startDate;
        }
        public void setCarReg(String CarReg)
        {
            this.carRegNo = CarReg;
        }
        public void setLicence(String licence)
        {
            this.typeLicence = licence;
        }
        public void setAccidents(int accident)
        {
            this.accident = accident;
        }
        public void setClaims(int claim)
        {
            this.claims = claims;
        }
        public void setPoints(int points)
        {
            this.points = points;
        }
        public void setPhn(int Phn)
        {
            this.phnNo = Phn;
        }


        //getters
        public String getTitle()
        {
            return title;
        }
        public String getFName()
        {
            return FName;
        }
        public String getLName()
        {
            return LName;
        }
        public String getDOB()
        {
            return dob;
        }
        public String getStart()
        {
            return startDate;
        }
        public String getCarReg()
        {
            return carRegNo;
        }
        public String getLicence()
        {
            return typeLicence;
        }
        public int getAccidents()
        {
            return accidents;
        }
        public int getClaims()
        {
            return claims;
        }
        public int getPoints()
        {
            return points;
        }
        public int getPhn()
        {
            return phnNo;
        }

    }

}

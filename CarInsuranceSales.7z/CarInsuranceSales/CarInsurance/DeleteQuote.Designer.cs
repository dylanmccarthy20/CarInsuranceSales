﻿
namespace CarInsurance
{
    partial class DeleteQuote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DeleteMnuStrip = new System.Windows.Forms.MenuStrip();
            this.BTMnuTLStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.grpDeleteQuote = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPhn = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblType = new System.Windows.Forms.Label();
            this.cboLicence = new System.Windows.Forms.ComboBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cboTitle = new System.Windows.Forms.ComboBox();
            this.txtCarReg = new System.Windows.Forms.TextBox();
            this.lblCarReg = new System.Windows.Forms.Label();
            this.lblLname = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.grpDelete = new System.Windows.Forms.GroupBox();
            this.cboClaims = new System.Windows.Forms.ComboBox();
            this.lblClaims = new System.Windows.Forms.Label();
            this.cboAccidents = new System.Windows.Forms.ComboBox();
            this.lblAccidents = new System.Windows.Forms.Label();
            this.cboFname = new System.Windows.Forms.ComboBox();
            this.cboLName = new System.Windows.Forms.ComboBox();
            this.cboReg = new System.Windows.Forms.ComboBox();
            this.cboPhn = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.cboType = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.DeleteMnuStrip.SuspendLayout();
            this.grpDeleteQuote.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpDelete.SuspendLayout();
            this.SuspendLayout();
            // 
            // DeleteMnuStrip
            // 
            this.DeleteMnuStrip.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.DeleteMnuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.DeleteMnuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMnuTLStrip});
            this.DeleteMnuStrip.Location = new System.Drawing.Point(0, 0);
            this.DeleteMnuStrip.Name = "DeleteMnuStrip";
            this.DeleteMnuStrip.Size = new System.Drawing.Size(800, 36);
            this.DeleteMnuStrip.TabIndex = 3;
            this.DeleteMnuStrip.Text = "menuStrip1";
            // 
            // BTMnuTLStrip
            // 
            this.BTMnuTLStrip.Name = "BTMnuTLStrip";
            this.BTMnuTLStrip.Size = new System.Drawing.Size(180, 30);
            this.BTMnuTLStrip.Text = "Back to Main Menu";
            this.BTMnuTLStrip.Click += new System.EventHandler(this.BTMnuTLStrip_Click);
            // 
            // grpDeleteQuote
            // 
            this.grpDeleteQuote.Controls.Add(this.groupBox1);
            this.grpDeleteQuote.Controls.Add(this.comboBox2);
            this.grpDeleteQuote.Controls.Add(this.btnSearch);
            this.grpDeleteQuote.Location = new System.Drawing.Point(12, 47);
            this.grpDeleteQuote.Name = "grpDeleteQuote";
            this.grpDeleteQuote.Size = new System.Drawing.Size(738, 154);
            this.grpDeleteQuote.TabIndex = 4;
            this.grpDeleteQuote.TabStop = false;
            this.grpDeleteQuote.Text = "Search";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblPhone);
            this.groupBox1.Controls.Add(this.txtPhn);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.lblType);
            this.groupBox1.Controls.Add(this.cboLicence);
            this.groupBox1.Controls.Add(this.lblTitle);
            this.groupBox1.Controls.Add(this.cboTitle);
            this.groupBox1.Controls.Add(this.txtCarReg);
            this.groupBox1.Controls.Add(this.lblCarReg);
            this.groupBox1.Controls.Add(this.lblLname);
            this.groupBox1.Controls.Add(this.lblFname);
            this.groupBox1.Controls.Add(this.txtLName);
            this.groupBox1.Controls.Add(this.txtFName);
            this.groupBox1.Location = new System.Drawing.Point(6, 206);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(738, 200);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(410, 83);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(119, 20);
            this.lblPhone.TabIndex = 22;
            this.lblPhone.Text = "Phone Number:";
            // 
            // txtPhn
            // 
            this.txtPhn.Location = new System.Drawing.Point(535, 80);
            this.txtPhn.MaxLength = 10;
            this.txtPhn.Name = "txtPhn";
            this.txtPhn.Size = new System.Drawing.Size(174, 26);
            this.txtPhn.TabIndex = 21;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(520, 134);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(189, 44);
            this.button1.TabIndex = 20;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(384, 36);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(127, 20);
            this.lblType.TabIndex = 13;
            this.lblType.Text = "Type Of Licence:";
            // 
            // cboLicence
            // 
            this.cboLicence.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLicence.FormattingEnabled = true;
            this.cboLicence.Items.AddRange(new object[] {
            "Full Irish",
            "Provisional"});
            this.cboLicence.Location = new System.Drawing.Point(535, 33);
            this.cboLicence.Name = "cboLicence";
            this.cboLicence.Size = new System.Drawing.Size(174, 28);
            this.cboLicence.TabIndex = 12;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(81, 33);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(42, 20);
            this.lblTitle.TabIndex = 11;
            this.lblTitle.Text = "Title:";
            // 
            // cboTitle
            // 
            this.cboTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTitle.FormattingEnabled = true;
            this.cboTitle.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboTitle.Location = new System.Drawing.Point(141, 29);
            this.cboTitle.Name = "cboTitle";
            this.cboTitle.Size = new System.Drawing.Size(121, 28);
            this.cboTitle.TabIndex = 10;
            // 
            // txtCarReg
            // 
            this.txtCarReg.Location = new System.Drawing.Point(165, 155);
            this.txtCarReg.Name = "txtCarReg";
            this.txtCarReg.Size = new System.Drawing.Size(163, 26);
            this.txtCarReg.TabIndex = 9;
            // 
            // lblCarReg
            // 
            this.lblCarReg.AutoSize = true;
            this.lblCarReg.Location = new System.Drawing.Point(16, 158);
            this.lblCarReg.Name = "lblCarReg";
            this.lblCarReg.Size = new System.Drawing.Size(128, 20);
            this.lblCarReg.TabIndex = 8;
            this.lblCarReg.Text = "Car Registration:";
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Location = new System.Drawing.Point(33, 114);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(90, 20);
            this.lblLname.TabIndex = 7;
            this.lblLname.Text = "Last Name:";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Location = new System.Drawing.Point(33, 71);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(90, 20);
            this.lblFname.TabIndex = 6;
            this.lblFname.Text = "First Name:";
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(141, 111);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(231, 26);
            this.txtLName.TabIndex = 5;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(141, 69);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(231, 26);
            this.txtFName.TabIndex = 4;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(237, 46);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(243, 28);
            this.comboBox2.TabIndex = 21;
            // 
            // btnSearch
            // 
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Location = new System.Drawing.Point(519, 93);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(189, 44);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // grpDelete
            // 
            this.grpDelete.Controls.Add(this.cboClaims);
            this.grpDelete.Controls.Add(this.lblClaims);
            this.grpDelete.Controls.Add(this.cboAccidents);
            this.grpDelete.Controls.Add(this.lblAccidents);
            this.grpDelete.Controls.Add(this.cboFname);
            this.grpDelete.Controls.Add(this.cboLName);
            this.grpDelete.Controls.Add(this.cboReg);
            this.grpDelete.Controls.Add(this.cboPhn);
            this.grpDelete.Controls.Add(this.label7);
            this.grpDelete.Controls.Add(this.btnDelete);
            this.grpDelete.Controls.Add(this.label8);
            this.grpDelete.Controls.Add(this.cboType);
            this.grpDelete.Controls.Add(this.label9);
            this.grpDelete.Controls.Add(this.txtTitle);
            this.grpDelete.Controls.Add(this.label10);
            this.grpDelete.Controls.Add(this.label11);
            this.grpDelete.Controls.Add(this.label12);
            this.grpDelete.Location = new System.Drawing.Point(12, 207);
            this.grpDelete.Name = "grpDelete";
            this.grpDelete.Size = new System.Drawing.Size(776, 232);
            this.grpDelete.TabIndex = 28;
            this.grpDelete.TabStop = false;
            this.grpDelete.Text = "Enter Details:";
            // 
            // cboClaims
            // 
            this.cboClaims.FormattingEnabled = true;
            this.cboClaims.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboClaims.Location = new System.Drawing.Point(141, 195);
            this.cboClaims.Name = "cboClaims";
            this.cboClaims.Size = new System.Drawing.Size(121, 28);
            this.cboClaims.TabIndex = 31;
            // 
            // lblClaims
            // 
            this.lblClaims.AutoSize = true;
            this.lblClaims.Location = new System.Drawing.Point(40, 200);
            this.lblClaims.Name = "lblClaims";
            this.lblClaims.Size = new System.Drawing.Size(60, 20);
            this.lblClaims.TabIndex = 30;
            this.lblClaims.Text = "Claims:";
            // 
            // cboAccidents
            // 
            this.cboAccidents.FormattingEnabled = true;
            this.cboAccidents.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboAccidents.Location = new System.Drawing.Point(536, 125);
            this.cboAccidents.Name = "cboAccidents";
            this.cboAccidents.Size = new System.Drawing.Size(173, 28);
            this.cboAccidents.TabIndex = 29;
            // 
            // lblAccidents
            // 
            this.lblAccidents.AutoSize = true;
            this.lblAccidents.Location = new System.Drawing.Point(410, 131);
            this.lblAccidents.Name = "lblAccidents";
            this.lblAccidents.Size = new System.Drawing.Size(83, 20);
            this.lblAccidents.TabIndex = 28;
            this.lblAccidents.Text = "Accidents:";
            // 
            // cboFname
            // 
            this.cboFname.FormattingEnabled = true;
            this.cboFname.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboFname.Location = new System.Drawing.Point(141, 70);
            this.cboFname.Name = "cboFname";
            this.cboFname.Size = new System.Drawing.Size(121, 28);
            this.cboFname.TabIndex = 27;
            // 
            // cboLName
            // 
            this.cboLName.FormattingEnabled = true;
            this.cboLName.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboLName.Location = new System.Drawing.Point(141, 114);
            this.cboLName.Name = "cboLName";
            this.cboLName.Size = new System.Drawing.Size(121, 28);
            this.cboLName.TabIndex = 26;
            // 
            // cboReg
            // 
            this.cboReg.FormattingEnabled = true;
            this.cboReg.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboReg.Location = new System.Drawing.Point(141, 154);
            this.cboReg.Name = "cboReg";
            this.cboReg.Size = new System.Drawing.Size(160, 28);
            this.cboReg.TabIndex = 25;
            // 
            // cboPhn
            // 
            this.cboPhn.FormattingEnabled = true;
            this.cboPhn.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboPhn.Location = new System.Drawing.Point(535, 83);
            this.cboPhn.Name = "cboPhn";
            this.cboPhn.Size = new System.Drawing.Size(173, 28);
            this.cboPhn.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(410, 83);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 20);
            this.label7.TabIndex = 22;
            this.label7.Text = "Phone Number:";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(520, 172);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(189, 44);
            this.btnDelete.TabIndex = 20;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(384, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 20);
            this.label8.TabIndex = 13;
            this.label8.Text = "Type Of Licence:";
            // 
            // cboType
            // 
            this.cboType.FormattingEnabled = true;
            this.cboType.Items.AddRange(new object[] {
            "Full Irish",
            "Provisional"});
            this.cboType.Location = new System.Drawing.Point(535, 33);
            this.cboType.Name = "cboType";
            this.cboType.Size = new System.Drawing.Size(174, 28);
            this.cboType.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(81, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 20);
            this.label9.TabIndex = 11;
            this.label9.Text = "Title:";
            // 
            // txtTitle
            // 
            this.txtTitle.FormattingEnabled = true;
            this.txtTitle.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.txtTitle.Location = new System.Drawing.Point(141, 29);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(121, 28);
            this.txtTitle.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 158);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 20);
            this.label10.TabIndex = 8;
            this.label10.Text = "Car Registration:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(33, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 20);
            this.label11.TabIndex = 7;
            this.label11.Text = "Last Name:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 20);
            this.label12.TabIndex = 6;
            this.label12.Text = "First Name:";
            // 
            // DeleteQuote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grpDelete);
            this.Controls.Add(this.grpDeleteQuote);
            this.Controls.Add(this.DeleteMnuStrip);
            this.Name = "DeleteQuote";
            this.Text = "DeleteQuote";
            this.Load += new System.EventHandler(this.DeleteQuote_Load);
            this.DeleteMnuStrip.ResumeLayout(false);
            this.DeleteMnuStrip.PerformLayout();
            this.grpDeleteQuote.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpDelete.ResumeLayout(false);
            this.grpDelete.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip DeleteMnuStrip;
        private System.Windows.Forms.ToolStripMenuItem BTMnuTLStrip;
        private System.Windows.Forms.GroupBox grpDeleteQuote;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtPhn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.ComboBox cboLicence;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cboTitle;
        private System.Windows.Forms.TextBox txtCarReg;
        private System.Windows.Forms.Label lblCarReg;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.GroupBox grpDelete;
        private System.Windows.Forms.ComboBox cboClaims;
        private System.Windows.Forms.Label lblClaims;
        private System.Windows.Forms.ComboBox cboAccidents;
        private System.Windows.Forms.Label lblAccidents;
        private System.Windows.Forms.ComboBox cboFname;
        private System.Windows.Forms.ComboBox cboLName;
        private System.Windows.Forms.ComboBox cboReg;
        private System.Windows.Forms.ComboBox cboPhn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboType;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox txtTitle;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarInsurance
{
    public interface ICouchRepository
    {
        Task<HttpClientResponse> PostDocumentAsync(CreateQuote create);
        Task<HttpClientResponse> PutDocumentAsync(UpdateQuote update);
        Task<HttpClientResponse> GetDocumentAsync(string id);
        Task<HttpClientResponse> DeleteDocumentAsync(string id, string rev);
    }
}

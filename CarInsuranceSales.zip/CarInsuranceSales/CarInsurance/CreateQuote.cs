﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarInsurance
{
    public partial class CreateQuote : Form
    {
        MainMenu parent;
        public CreateQuote()
        {
            InitializeComponent();
        }
        public CreateQuote(MainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }

        private void CreateQuote_Load(object sender, EventArgs e)
        {

        }

        private void BTMnuTLStrip_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void lbldtp_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if(txtFName == null || txtCarReg == null || txtLName == null || cboaccident.SelectedIndex==-1 || cboLicence.SelectedIndex==-1 || cboTitle.SelectedIndex==-1 || dtpDate.Value >= DateTime.Now)
            {
                MessageBox.Show("Not All details were entered correctly!");
            }
                                             
            Quotes newquote = new Quotes(cboTitle.Text, txtFName.Text, txtLName.Text, (String.Format("{0:dd-MMM-yy}", dtpDOB.Value)), (String.Format("{0:dd-MMM-yy}", dtpDate.Value)),
                txtCarReg.Text, cboLicence.Text, Convert.ToInt32(cboNCB.Text), Convert.ToInt32(cboPoints.Text), Convert.ToInt32(txtPhn.Text));
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void cboLicence_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

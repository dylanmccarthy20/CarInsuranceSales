﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarInsurance
{
    public partial class ViewQuote : Form
    {
        MainMenu parent;
        public ViewQuote()
        {
            InitializeComponent();
        }
        public ViewQuote(MainMenu Parent)
        {
            InitializeComponent();
            parent = Parent;
        }
        private void ViewQuotes_Load(object sender, EventArgs e)
        {

        }

        private void BTMnuTLStrip_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }
    }
}

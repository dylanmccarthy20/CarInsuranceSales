﻿
namespace CarInsurance
{
    partial class ViewQuote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ViewMnuStrip = new System.Windows.Forms.MenuStrip();
            this.BTMnuTLStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.grpDeleteQuote = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPhn = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblType = new System.Windows.Forms.Label();
            this.cboLicence = new System.Windows.Forms.ComboBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cboTitle = new System.Windows.Forms.ComboBox();
            this.txtCarReg = new System.Windows.Forms.TextBox();
            this.lblCarReg = new System.Windows.Forms.Label();
            this.lblLname = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.searchtext = new System.Windows.Forms.ComboBox();
            this.btnSearchUpd = new System.Windows.Forms.Button();
            this.ViewMnuStrip.SuspendLayout();
            this.grpDeleteQuote.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ViewMnuStrip
            // 
            this.ViewMnuStrip.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.ViewMnuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.ViewMnuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMnuTLStrip});
            this.ViewMnuStrip.Location = new System.Drawing.Point(0, 0);
            this.ViewMnuStrip.Name = "ViewMnuStrip";
            this.ViewMnuStrip.Size = new System.Drawing.Size(800, 36);
            this.ViewMnuStrip.TabIndex = 2;
            this.ViewMnuStrip.Text = "menuStrip1";
            // 
            // BTMnuTLStrip
            // 
            this.BTMnuTLStrip.Name = "BTMnuTLStrip";
            this.BTMnuTLStrip.Size = new System.Drawing.Size(180, 32);
            this.BTMnuTLStrip.Text = "Back to Main Menu";
            this.BTMnuTLStrip.Click += new System.EventHandler(this.BTMnuTLStrip_Click);
            // 
            // grpDeleteQuote
            // 
            this.grpDeleteQuote.Controls.Add(this.groupBox1);
            this.grpDeleteQuote.Controls.Add(this.searchtext);
            this.grpDeleteQuote.Controls.Add(this.btnSearchUpd);
            this.grpDeleteQuote.Location = new System.Drawing.Point(24, 47);
            this.grpDeleteQuote.Name = "grpDeleteQuote";
            this.grpDeleteQuote.Size = new System.Drawing.Size(738, 154);
            this.grpDeleteQuote.TabIndex = 7;
            this.grpDeleteQuote.TabStop = false;
            this.grpDeleteQuote.Text = "Search";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblPhone);
            this.groupBox1.Controls.Add(this.txtPhn);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.lblType);
            this.groupBox1.Controls.Add(this.cboLicence);
            this.groupBox1.Controls.Add(this.lblTitle);
            this.groupBox1.Controls.Add(this.cboTitle);
            this.groupBox1.Controls.Add(this.txtCarReg);
            this.groupBox1.Controls.Add(this.lblCarReg);
            this.groupBox1.Controls.Add(this.lblLname);
            this.groupBox1.Controls.Add(this.lblFname);
            this.groupBox1.Controls.Add(this.txtLName);
            this.groupBox1.Controls.Add(this.txtFName);
            this.groupBox1.Location = new System.Drawing.Point(6, 206);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(738, 200);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(410, 83);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(119, 20);
            this.lblPhone.TabIndex = 22;
            this.lblPhone.Text = "Phone Number:";
            // 
            // txtPhn
            // 
            this.txtPhn.Location = new System.Drawing.Point(535, 80);
            this.txtPhn.MaxLength = 10;
            this.txtPhn.Name = "txtPhn";
            this.txtPhn.Size = new System.Drawing.Size(174, 26);
            this.txtPhn.TabIndex = 21;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(520, 134);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(189, 44);
            this.button1.TabIndex = 20;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(384, 36);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(127, 20);
            this.lblType.TabIndex = 13;
            this.lblType.Text = "Type Of Licence:";
            // 
            // cboLicence
            // 
            this.cboLicence.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLicence.FormattingEnabled = true;
            this.cboLicence.Items.AddRange(new object[] {
            "Full Irish",
            "Provisional"});
            this.cboLicence.Location = new System.Drawing.Point(535, 33);
            this.cboLicence.Name = "cboLicence";
            this.cboLicence.Size = new System.Drawing.Size(174, 28);
            this.cboLicence.TabIndex = 12;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(81, 33);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(42, 20);
            this.lblTitle.TabIndex = 11;
            this.lblTitle.Text = "Title:";
            // 
            // cboTitle
            // 
            this.cboTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTitle.FormattingEnabled = true;
            this.cboTitle.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboTitle.Location = new System.Drawing.Point(141, 29);
            this.cboTitle.Name = "cboTitle";
            this.cboTitle.Size = new System.Drawing.Size(121, 28);
            this.cboTitle.TabIndex = 10;
            // 
            // txtCarReg
            // 
            this.txtCarReg.Location = new System.Drawing.Point(165, 155);
            this.txtCarReg.Name = "txtCarReg";
            this.txtCarReg.Size = new System.Drawing.Size(163, 26);
            this.txtCarReg.TabIndex = 9;
            // 
            // lblCarReg
            // 
            this.lblCarReg.AutoSize = true;
            this.lblCarReg.Location = new System.Drawing.Point(16, 158);
            this.lblCarReg.Name = "lblCarReg";
            this.lblCarReg.Size = new System.Drawing.Size(128, 20);
            this.lblCarReg.TabIndex = 8;
            this.lblCarReg.Text = "Car Registration:";
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Location = new System.Drawing.Point(33, 114);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(90, 20);
            this.lblLname.TabIndex = 7;
            this.lblLname.Text = "Last Name:";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Location = new System.Drawing.Point(33, 71);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(90, 20);
            this.lblFname.TabIndex = 6;
            this.lblFname.Text = "First Name:";
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(141, 111);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(231, 26);
            this.txtLName.TabIndex = 5;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(141, 69);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(231, 26);
            this.txtFName.TabIndex = 4;
            // 
            // searchtext
            // 
            this.searchtext.FormattingEnabled = true;
            this.searchtext.Location = new System.Drawing.Point(237, 46);
            this.searchtext.Name = "searchtext";
            this.searchtext.Size = new System.Drawing.Size(221, 28);
            this.searchtext.TabIndex = 21;
            // 
            // btnSearchUpd
            // 
            this.btnSearchUpd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchUpd.Location = new System.Drawing.Point(519, 93);
            this.btnSearchUpd.Name = "btnSearchUpd";
            this.btnSearchUpd.Size = new System.Drawing.Size(189, 44);
            this.btnSearchUpd.TabIndex = 20;
            this.btnSearchUpd.Text = "Search";
            this.btnSearchUpd.UseVisualStyleBackColor = true;
            // 
            // ViewQuote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grpDeleteQuote);
            this.Controls.Add(this.ViewMnuStrip);
            this.Name = "ViewQuote";
            this.Text = "ViewQuotes";
            this.Load += new System.EventHandler(this.ViewQuotes_Load);
            this.ViewMnuStrip.ResumeLayout(false);
            this.ViewMnuStrip.PerformLayout();
            this.grpDeleteQuote.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip ViewMnuStrip;
        private System.Windows.Forms.ToolStripMenuItem BTMnuTLStrip;
        private System.Windows.Forms.GroupBox grpDeleteQuote;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtPhn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.ComboBox cboLicence;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cboTitle;
        private System.Windows.Forms.TextBox txtCarReg;
        private System.Windows.Forms.Label lblCarReg;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.ComboBox searchtext;
        private System.Windows.Forms.Button btnSearchUpd;
    }
}
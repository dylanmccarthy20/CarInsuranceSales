﻿
namespace CarInsurance
{
    partial class UpdateQuote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UpdMnuStrip = new System.Windows.Forms.MenuStrip();
            this.BTMnuTLStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboFname = new System.Windows.Forms.ComboBox();
            this.cboLName = new System.Windows.Forms.ComboBox();
            this.cboCar = new System.Windows.Forms.ComboBox();
            this.cboPhone = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cbotype = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.grpDeleteQuote = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPhn = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblType = new System.Windows.Forms.Label();
            this.cboLicence = new System.Windows.Forms.ComboBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cboTitle = new System.Windows.Forms.ComboBox();
            this.txtCarReg = new System.Windows.Forms.TextBox();
            this.lblCarReg = new System.Windows.Forms.Label();
            this.lblLname = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.searchtext = new System.Windows.Forms.ComboBox();
            this.btnSearchUpd = new System.Windows.Forms.Button();
            this.UpdMnuStrip.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpDeleteQuote.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // UpdMnuStrip
            // 
            this.UpdMnuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.UpdMnuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BTMnuTLStrip});
            this.UpdMnuStrip.Location = new System.Drawing.Point(0, 0);
            this.UpdMnuStrip.Name = "UpdMnuStrip";
            this.UpdMnuStrip.Size = new System.Drawing.Size(800, 36);
            this.UpdMnuStrip.TabIndex = 2;
            this.UpdMnuStrip.Text = "menuStrip1";
            // 
            // BTMnuTLStrip
            // 
            this.BTMnuTLStrip.Name = "BTMnuTLStrip";
            this.BTMnuTLStrip.Size = new System.Drawing.Size(180, 30);
            this.BTMnuTLStrip.Text = "Back to Main Menu";
            this.BTMnuTLStrip.Click += new System.EventHandler(this.BTMnuTLStrip_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboFname);
            this.groupBox2.Controls.Add(this.cboLName);
            this.groupBox2.Controls.Add(this.cboCar);
            this.groupBox2.Controls.Add(this.cboPhone);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnUpdate);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cbotype);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtTitle);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(12, 186);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(776, 239);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox1";
            // 
            // cboFname
            // 
            this.cboFname.FormattingEnabled = true;
            this.cboFname.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboFname.Location = new System.Drawing.Point(141, 70);
            this.cboFname.Name = "cboFname";
            this.cboFname.Size = new System.Drawing.Size(121, 28);
            this.cboFname.TabIndex = 27;
            // 
            // cboLName
            // 
            this.cboLName.FormattingEnabled = true;
            this.cboLName.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboLName.Location = new System.Drawing.Point(141, 114);
            this.cboLName.Name = "cboLName";
            this.cboLName.Size = new System.Drawing.Size(121, 28);
            this.cboLName.TabIndex = 26;
            // 
            // cboCar
            // 
            this.cboCar.FormattingEnabled = true;
            this.cboCar.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboCar.Location = new System.Drawing.Point(147, 155);
            this.cboCar.Name = "cboCar";
            this.cboCar.Size = new System.Drawing.Size(160, 28);
            this.cboCar.TabIndex = 25;
            // 
            // cboPhone
            // 
            this.cboPhone.FormattingEnabled = true;
            this.cboPhone.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboPhone.Location = new System.Drawing.Point(535, 83);
            this.cboPhone.Name = "cboPhone";
            this.cboPhone.Size = new System.Drawing.Size(173, 28);
            this.cboPhone.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(410, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 20);
            this.label1.TabIndex = 22;
            this.label1.Text = "Phone Number:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(520, 134);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(189, 44);
            this.btnUpdate.TabIndex = 20;
            this.btnUpdate.Text = "Submit";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(384, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Type Of Licence:";
            // 
            // cbotype
            // 
            this.cbotype.FormattingEnabled = true;
            this.cbotype.Items.AddRange(new object[] {
            "Full Irish",
            "Provisional"});
            this.cbotype.Location = new System.Drawing.Point(535, 33);
            this.cbotype.Name = "cbotype";
            this.cbotype.Size = new System.Drawing.Size(174, 28);
            this.cbotype.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(81, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Title:";
            // 
            // txtTitle
            // 
            this.txtTitle.FormattingEnabled = true;
            this.txtTitle.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.txtTitle.Location = new System.Drawing.Point(141, 29);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(121, 28);
            this.txtTitle.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Car Registration:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Last Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "First Name:";
            // 
            // grpDeleteQuote
            // 
            this.grpDeleteQuote.Controls.Add(this.groupBox1);
            this.grpDeleteQuote.Controls.Add(this.searchtext);
            this.grpDeleteQuote.Controls.Add(this.btnSearchUpd);
            this.grpDeleteQuote.Location = new System.Drawing.Point(12, 25);
            this.grpDeleteQuote.Name = "grpDeleteQuote";
            this.grpDeleteQuote.Size = new System.Drawing.Size(738, 154);
            this.grpDeleteQuote.TabIndex = 6;
            this.grpDeleteQuote.TabStop = false;
            this.grpDeleteQuote.Text = "Search";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblPhone);
            this.groupBox1.Controls.Add(this.txtPhn);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.lblType);
            this.groupBox1.Controls.Add(this.cboLicence);
            this.groupBox1.Controls.Add(this.lblTitle);
            this.groupBox1.Controls.Add(this.cboTitle);
            this.groupBox1.Controls.Add(this.txtCarReg);
            this.groupBox1.Controls.Add(this.lblCarReg);
            this.groupBox1.Controls.Add(this.lblLname);
            this.groupBox1.Controls.Add(this.lblFname);
            this.groupBox1.Controls.Add(this.txtLName);
            this.groupBox1.Controls.Add(this.txtFName);
            this.groupBox1.Location = new System.Drawing.Point(6, 206);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(738, 200);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(410, 83);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(119, 20);
            this.lblPhone.TabIndex = 22;
            this.lblPhone.Text = "Phone Number:";
            // 
            // txtPhn
            // 
            this.txtPhn.Location = new System.Drawing.Point(535, 80);
            this.txtPhn.MaxLength = 10;
            this.txtPhn.Name = "txtPhn";
            this.txtPhn.Size = new System.Drawing.Size(174, 26);
            this.txtPhn.TabIndex = 21;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(520, 134);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(189, 44);
            this.button1.TabIndex = 20;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(384, 36);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(127, 20);
            this.lblType.TabIndex = 13;
            this.lblType.Text = "Type Of Licence:";
            // 
            // cboLicence
            // 
            this.cboLicence.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLicence.FormattingEnabled = true;
            this.cboLicence.Items.AddRange(new object[] {
            "Full Irish",
            "Provisional"});
            this.cboLicence.Location = new System.Drawing.Point(535, 33);
            this.cboLicence.Name = "cboLicence";
            this.cboLicence.Size = new System.Drawing.Size(174, 28);
            this.cboLicence.TabIndex = 12;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(81, 33);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(42, 20);
            this.lblTitle.TabIndex = 11;
            this.lblTitle.Text = "Title:";
            // 
            // cboTitle
            // 
            this.cboTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTitle.FormattingEnabled = true;
            this.cboTitle.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Mrs"});
            this.cboTitle.Location = new System.Drawing.Point(141, 29);
            this.cboTitle.Name = "cboTitle";
            this.cboTitle.Size = new System.Drawing.Size(121, 28);
            this.cboTitle.TabIndex = 10;
            // 
            // txtCarReg
            // 
            this.txtCarReg.Location = new System.Drawing.Point(165, 155);
            this.txtCarReg.Name = "txtCarReg";
            this.txtCarReg.Size = new System.Drawing.Size(163, 26);
            this.txtCarReg.TabIndex = 9;
            // 
            // lblCarReg
            // 
            this.lblCarReg.AutoSize = true;
            this.lblCarReg.Location = new System.Drawing.Point(16, 158);
            this.lblCarReg.Name = "lblCarReg";
            this.lblCarReg.Size = new System.Drawing.Size(128, 20);
            this.lblCarReg.TabIndex = 8;
            this.lblCarReg.Text = "Car Registration:";
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Location = new System.Drawing.Point(33, 114);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(90, 20);
            this.lblLname.TabIndex = 7;
            this.lblLname.Text = "Last Name:";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Location = new System.Drawing.Point(33, 71);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(90, 20);
            this.lblFname.TabIndex = 6;
            this.lblFname.Text = "First Name:";
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(141, 111);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(231, 26);
            this.txtLName.TabIndex = 5;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(141, 69);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(231, 26);
            this.txtFName.TabIndex = 4;
            // 
            // searchtext
            // 
            this.searchtext.FormattingEnabled = true;
            this.searchtext.Location = new System.Drawing.Point(237, 46);
            this.searchtext.Name = "searchtext";
            this.searchtext.Size = new System.Drawing.Size(221, 28);
            this.searchtext.TabIndex = 21;
            // 
            // btnSearchUpd
            // 
            this.btnSearchUpd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchUpd.Location = new System.Drawing.Point(519, 93);
            this.btnSearchUpd.Name = "btnSearchUpd";
            this.btnSearchUpd.Size = new System.Drawing.Size(189, 44);
            this.btnSearchUpd.TabIndex = 20;
            this.btnSearchUpd.Text = "Search";
            this.btnSearchUpd.UseVisualStyleBackColor = true;
            // 
            // UpdateQuote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grpDeleteQuote);
            this.Controls.Add(this.UpdMnuStrip);
            this.Name = "UpdateQuote";
            this.Text = "UpdateQuote";
            this.Load += new System.EventHandler(this.UpdateQuote_Load);
            this.UpdMnuStrip.ResumeLayout(false);
            this.UpdMnuStrip.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpDeleteQuote.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip UpdMnuStrip;
        private System.Windows.Forms.ToolStripMenuItem BTMnuTLStrip;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cboFname;
        private System.Windows.Forms.ComboBox cboLName;
        private System.Windows.Forms.ComboBox cboCar;
        private System.Windows.Forms.ComboBox cboPhone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbotype;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox txtTitle;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox grpDeleteQuote;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtPhn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.ComboBox cboLicence;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cboTitle;
        private System.Windows.Forms.TextBox txtCarReg;
        private System.Windows.Forms.Label lblCarReg;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.ComboBox searchtext;
        private System.Windows.Forms.Button btnSearchUpd;
    }
}
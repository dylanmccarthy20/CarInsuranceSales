﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarInsurance
{
    class Quotes
    {
        private String FName;
        private String LName;
        private String title;
        private String dob;
        private String startDate;
        private String carRegNo;
        private String typeLicence;
        private int claims;
        private int points;
        private int phnNo;
        public Quotes()
        {
            FName = "";
            LName = "";
            title = "";
            dob = "";
            startDate = "";
            carRegNo = "";
            typeLicence = "";
            claims = 0;
            points = 0;
            phnNo = 0;
        }
        
        public Quotes (String title, String fname, String lname,String dob,String startDate,
            String carRegNo, String type,int claims, int points, int phn) 
        {
            this.FName = fname;
            this.LName = lname;
            this.title = title;
            this.dob = dob;
            this.startDate = startDate;
            this.carRegNo = carRegNo;
            this.typeLicence = type;
            this.claims = claims;
            this.points = points;
            this.phnNo = phn;
        }
    }
   
}
